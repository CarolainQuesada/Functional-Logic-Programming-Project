var searchData=
[
  ['identifier_0',['identifier',['../api_src__parser.html#api_src_Parser_identifier',1,'']]],
  ['implementation_1',['Completed implementation',['../md_docs_2team-handoff.html#autotoc_md56',1,'']]],
  ['improvements_2',['Assignment compatibility and delivery improvements',['../md_docs_2verification.html#autotoc_md70',1,'']]],
  ['inicio_20rápido_3',['Inicio rápido',['../index.html#autotoc_md2',1,'']]],
  ['input_20format_20analysis_4',['input-format-analysis',['../md_docs_2input-format-analysis.html',1,'']]],
  ['input_20hs_5',['src/Input.hs',['../api_src__input.html',1,'']]],
  ['input_20parser_6',['Functional input parser',['../md_docs_2parser.html',1,'']]],
  ['inputfailure_7',['inputFailure',['../api_src__pipeline.html#api_src_Pipeline_inputFailure',1,'']]],
  ['inspection_8',['Interactive inspection',['../index.html#autotoc_md4',1,'']]],
  ['interactive_20inspection_9',['Interactive inspection',['../index.html#autotoc_md4',1,'']]],
  ['interface_10',['Generated interface',['../md_docs_2generated-interface.html',1,'']]],
  ['intermediate_20model_11',['Intermediate model',['../md_docs_2intermediate-model.html',1,'']]],
  ['invariants_12',['Output and failure invariants',['../md_docs_2architecture.html#autotoc_md15',1,'']]],
  ['issues_20found_20and_20resolved_13',['Issues found and resolved',['../md_docs_2verification.html#autotoc_md68',1,'']]],
  ['isteaching_14',['isTeaching',['../api_src__prolog.html#api_src_Prolog_isTeaching',1,'']]]
];
